const CAIRN_SESSION_ASSETS = {
  "Easy Run": "easy_run",
  "Recovery Run": "recovery_run",
  "Long Run": "long_run",
  "Long Trail Run": "long_run",
  "Trail Run": "trail_run",
  "Hill Session": "hill_session",
  "Interval Session": "interval_session",
  "Interval Run": "interval_session",
  "Tempo Session": "tempo_session",
  "Tempo Run": "tempo_session",
  "Sprint Session": "sprint_session",
  "Time Trial": "time_trial",
  "Time Trail": "time_trial",
  "Strength Training": "strength_training",
  "Upper Body CAIRN": "strength_training",
  "Lower Body + Arms CAIRN": "strength_training",
  "Full Body Light CAIRN": "strength_training",
  "Cross Training": "cross_training",
  "Mobility": "mobility",
  "Rest Day": "rest_day",
  "Rest": "rest_day",
  "Race Day": "race_day"
};

const STRUCTURED_SESSION_TYPES = new Set([
  "Hill Session",
  "Interval Session",
  "Interval Run",
  "Tempo Session",
  "Tempo Run",
  "Sprint Session",
  "Time Trial",
  "Time Trail"
]);

export function getCairnSessionAsset(sessionType, format = "svg") {
  const key = CAIRN_SESSION_ASSETS[sessionType] || "cairn";
  const extension = format === "png" ? "png" : "svg";
  return `/static/assets/cairn/${extension}/${key}.${extension}`;
}

export function hasStructuredWorkoutProfile(sessionType) {
  return STRUCTURED_SESSION_TYPES.has(sessionType);
}

export { CAIRN_SESSION_ASSETS, STRUCTURED_SESSION_TYPES };
