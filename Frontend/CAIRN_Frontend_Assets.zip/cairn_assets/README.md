# CAIRN Asset-Paket

Dieses Paket enthält 15 freigestellte CAIRN-Grafiken für das Frontend.

## Technischer Zustand

- transparenter Hintergrund
- keine weiße Seitenfläche
- transparente Innenräume außerhalb der gezeichneten Formen
- SVG-Seitenfläche eng auf das Motiv zugeschnitten, mit Sicherheitsrand
- alle Texte in Vektorpfade umgewandelt
- keine Abhängigkeit von der Schrift `HV SMEGS`
- PNG-Fallbacks mit 1600 px Breite und Alpha-Transparenz
- Originaldateien wurden nicht verändert

## Verzeichnisse

- `svg/`: bevorzugte Frontend-Assets
- `png/`: transparente Fallbacks und PDF-Assets
- `assets-manifest.json`: vollständiger Katalog und Session-Zuordnung
- `session-assets.js`: direkt nutzbare Frontend-Zuordnung
- `contact_sheet.png`: visuelle Übersicht auf neutralem Prüfhintergrund

## Frontend-Verwendung

Bevorzugt wird das SVG über ein normales `img`-Element geladen:

```html
<img
  class="session-card__art"
  src="/static/assets/cairn/svg/long_run.svg"
  alt=""
  aria-hidden="true"
>
```

```css
.session-card {
  position: relative;
  overflow: hidden;
}

.session-card__art {
  position: absolute;
  right: -2%;
  bottom: -5%;
  width: min(48%, 240px);
  height: auto;
  object-fit: contain;
  pointer-events: none;
}
```

Die Grafik wird ausschließlich im Frontend über `session_type` ausgewählt. In der Datenbank müssen weder Bilddateien noch Dateipfade gespeichert werden.

## Strukturierte Workouts

Hill-, Intervall-, Tempo-, Sprint- und Time-Trial-Einheiten erhalten zusätzlich eine dynamisch erzeugte graue Workout-Struktur. Diese Struktur wird aus Warm-up-, Intervall-, Recovery- und Cooldown-Schritten gezeichnet und ist kein statisches Asset.

## Fallback

Unbekannte `session_type`-Werte verwenden `cairn.svg`. Die Alias-Namen in `assets-manifest.json` und `session-assets.js` verhindern Probleme mit bestehenden Bezeichnungen wie `Interval Run`/`Interval Session` oder dem bisherigen Tippfehler `Time Trail`.
